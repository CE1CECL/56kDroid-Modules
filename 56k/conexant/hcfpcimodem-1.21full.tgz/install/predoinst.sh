#!/bin/bash
if [ "$1" = 1 ]; then
	if [ -e "/etc/hcfpcimodem" ]; then
		echo "Removing old /etc/hcfpcimodem"
		rm -rf "/etc/hcfpcimodem"
	fi
	if [ -e "/usr/lib/hcfpcimodem" ]; then
		echo "Removing old /usr/lib/hcfpcimodem"
		rm -rf "/usr/lib/hcfpcimodem"
	fi
fi
exit 0