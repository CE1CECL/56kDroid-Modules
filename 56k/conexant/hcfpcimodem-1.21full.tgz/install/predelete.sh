#!/bin/bash
/usr/sbin/hcfpcistop
if [ "$1" = 0 ]; then

	if [ -z "${CNXT_NOAUTOCONFIG}" ]; then
		/usr/sbin/hcfpciconfig --remove
	fi

	if [ -f /etc/hcfpcimodem/nvm.tar.gz ]; then
		( cd /etc/hcfpcimodem && rm -rf `tar tzf /etc/hcfpcimodem/nvm.tar.gz | egrep '^nvm/[^/]+/?$'` )
	fi
else
	exit 0
fi


# This must be last since the file CHANGES is automatically appended