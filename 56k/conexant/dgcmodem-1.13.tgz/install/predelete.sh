#!/bin/bash
/usr/sbin/dgcstop
if [ "$1" = 0 ]; then

	if [ -z "${CNXT_NOAUTOCONFIG}" ]; then
		/usr/sbin/dgcconfig --remove
	fi

	if [ -f /etc/dgcmodem/nvm.tar.gz ]; then
		( cd /etc/dgcmodem && rm -rf `tar tzf /etc/dgcmodem/nvm.tar.gz | egrep '^nvm/[^/]+/?$'` )
	fi
else
	exit 0
fi


# This must be last since the file CHANGES is automatically appended