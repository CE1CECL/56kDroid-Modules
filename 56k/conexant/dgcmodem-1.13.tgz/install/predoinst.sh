#!/bin/bash
if [ "$1" = 1 ]; then
	if [ -e "/etc/dgcmodem" ]; then
		echo "Removing old /etc/dgcmodem"
		rm -rf "/etc/dgcmodem"
	fi
	if [ -e "/usr/lib/dgcmodem" ]; then
		echo "Removing old /usr/lib/dgcmodem"
		rm -rf "/usr/lib/dgcmodem"
	fi
fi
exit 0